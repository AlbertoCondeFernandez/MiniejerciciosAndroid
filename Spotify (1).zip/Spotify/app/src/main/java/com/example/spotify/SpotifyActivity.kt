package com.example.spotify

/** LEER ESTO ANTES DE NADA
 * A este proyecto le he incluido un par de cosas diferentes respecto a otros que hemos hecho.
 *
 * A la misma altura que la carpeta res he añadido la carpeta assets para poner ahí las imágenes de
 * las canciones. El código que accede a ellas está en getView del {@link SpotifyAdapter}.
 *
 * Dentro de res, ahora está la carpeta raw, que es para arhcivos a palo. En este caso, un archivo
 * de texto del tipo CSV (buscad en Google). En el {@link SpotifyActivity#onCreate} se ve
 * cómo se lee el archivo y cómo se separan los campos.
 *
 * Echad un vistado a los layout también y comparad con los vuestros.
 */


import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.opencsv.CSVReader
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

/**
 * Clase que usamos por comodida y orden.
 */
class Cancion(val titulo: String, val artistas: List<String>, val imagen: String)

/**
 * Adapter para nuetro layout de canciones de Spotify.
 * @param contexto Contexto de la actividad.
 * @param datos Lista de Canciones.
 */
class SpotifyAdapter(
    private val contexto: Context,
    private val datos: List<Cancion>
) : BaseAdapter() {

    override fun getCount(): Int {
        return datos.size
    }

    override fun getItem(position: Int): Any {
        return datos[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(contexto).inflate(
            R.layout.item_spotify, parent, false
        )

        val imagenView: ImageView = view.findViewById(R.id.albumView)
        val tituloText: TextView = view.findViewById(R.id.tituloText)
        val artistasText: TextView = view.findViewById(R.id.artistasText)

        val dato = datos[position]

        var entrada: InputStream? = null
        var imagen: Bitmap? = null
        try {
            entrada = contexto.assets.open(dato.imagen) // Ruta de la imagen
            imagen = BitmapFactory.decodeStream(entrada) // Leer la imagen
            imagenView.setImageBitmap(imagen) // Asignar la imagen al ImageView
        } catch (e: IOException) {
            imagenView.setImageResource(R.drawable.ic_error) // Imagen por defecto
        }

        val limTit = contexto.resources.getInteger(R.integer.limite_titulo)
        val limArt = contexto.resources.getInteger(R.integer.limite_artistas)
        if (dato.titulo.length > limTit - 3)
            tituloText.text = dato.titulo.substring(0, limTit) + "..."
        else
            tituloText.text = dato.titulo

        val aux = dato.artistas.joinToString(", ")
        if (aux.length > limArt - 3)
            artistasText.text = aux.substring(0, limArt) + "..."
        else
            artistasText.text = aux

        return (view)
    }

}

class SpotifyActivity : AppCompatActivity() {
    private lateinit var lista: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_spotify)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        lista = findViewById(R.id.listaSpotify)

        val datos = mutableListOf<Cancion>()

        /*
        Aquí se lee el archivo res/raw/datos.csv, que funciona parecido a un excel/base de datos.
        En este caso, hay 3 columnas: titulo, artistas, imagen
        Cada línea es texto plano, pero para separar las columnas se utiliza el punt y coma (;).
        Para la lista de artistas, se separan con coma (,).
         */
        try {
            // R.raw.datos: nombre del archivo CSV
            val inputStream = resources.openRawResource(R.raw.datos)
            val reader = CSVReader( // Esto es para leer el CSV
                BufferedReader(
                    InputStreamReader(
                        inputStream,           // Stream de la entrada
                        StandardCharsets.UTF_8 // Especificar la codificación
                    )
                )
            )
            var linea = reader.readNext().toString() // Leer/quitar la primera línea (cabecera)
            var partes: List<String> // Esto es para luego separar la línea
            while (reader.readNext().also { linea = it.joinToString() } != null) {
                partes = linea.split(";") // Separar las columnas
                datos.add(
                    Cancion(
                        partes[0], // Título de canción
                        partes[1].split(","), // Lista de artistas (separados por ,)
                        partes[2] // Imagen
                    )
                )
            }
            reader.close()
        } catch (e: Exception) {
            // Idk
        }

        val adaptador = SpotifyAdapter(this, datos)
        lista.adapter = adaptador
    }
}