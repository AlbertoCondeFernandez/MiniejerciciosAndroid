package com.example.ejercicios_interfaces

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Ejercicio3 : AppCompatActivity() {
    private lateinit var titulo: TextView
    private lateinit var usuario: EditText
    private lateinit var email: EditText
    private lateinit var pass: EditText
    private lateinit var passRe: EditText
    private lateinit var botonRegis: Button
    private lateinit var inicio: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_ejercicio3)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        titulo = findViewById(R.id.titulo)
        usuario = findViewById(R.id.editUsuario)
        email = findViewById(R.id.editEmail)
        pass = findViewById(R.id.editPass)
        passRe = findViewById(R.id.editPassRe)
        botonRegis = findViewById(R.id.registrarse)
        inicio = findViewById(R.id.textInicio)
        inicio.setOnClickListener {
            usuario.setText("flipao")
            email.setText("flipao@flipadin.es")
            pass.setText("flipao")
            passRe.setText("flipao")

        }
    }

    fun registrarse(v: View) {
        if (pass.text.toString() == passRe.text.toString() && // Que las dos constraseñas coincidan
            pass.text.toString() != "" && // Que no sea un contraseña vacía
            pass.text.length >= 4 && pass.text.length <= 16 // Que tenga min/max de carácteres
        ) {
            // TODO: Hacer algo si todo va bien
            pass.setTextColor(Color.WHITE)
            passRe.setTextColor(Color.WHITE)
        } else {
            // TODO: Hacer algo si algo va mal
            pass.setTextColor(Color.RED)
            passRe.setTextColor(Color.RED)
        }
    }
}