package com.example.ejercicios_interfaces

import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.children
import androidx.recyclerview.widget.RecyclerView.Orientation

class Ejercicio1 : AppCompatActivity() {
    private lateinit var tareas: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_ejercicio1)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        tareas = findViewById(R.id.tareas)
    }

    fun addTask(v: View) {
        // Aquí se va a crear un LinearLayout que se compone de:
        // - Un CheckBox
        // - Un EditText
        // El Layout tendrá orientación horizontal

        val cb = CheckBox(this)
        val et = EditText(this)
        et.hint = "Escribe la tarea"

        cb.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                et.paintFlags = et.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                et.setTextColor(Color.parseColor("#b3b3b3"))

            } else {
                et.paintFlags = et.paintFlags and (Paint.STRIKE_THRU_TEXT_FLAG.inv())
                et.setTextColor(Color.parseColor("#000000"))
            }
        }

        val ll = LinearLayout(this)
        ll.addView(cb)
        ll.addView(et)
        ll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, // Primero width
            ViewGroup.LayoutParams.WRAP_CONTENT, // Segundo height
        )
        ll.gravity = Gravity.CENTER
        ll.orientation = LinearLayout.HORIZONTAL
        tareas.addView(ll)
    }

    fun removeTask(v: View) {
        tareas.removeView(tareas.children.last())
    }
}